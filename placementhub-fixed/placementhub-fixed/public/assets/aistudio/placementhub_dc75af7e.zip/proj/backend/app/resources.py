"""Generic, permission-checked, department/company/assignment-scoped CRUD for domain resources."""
import csv
import io
import re
from datetime import date, datetime

from flask import Blueprint, g, jsonify, request
from sqlalchemy import Boolean, Date, Float, Integer, false
from sqlalchemy.exc import IntegrityError

from .auth import can, require_auth
from .errors import ApiError
from .extensions import db
from .models import (Application, Company, Department, Internship, Notification, Outreach, PlacementOffer,
                     RecruitmentDrive, Student, User, Vacancy, VacancyVerification, camel, utcnow)
from .permissions import COORDINATOR, DIRECTOR, RECRUITER, SUPER_ADMIN, TPO
from .services import audit

bp = Blueprint("resources", __name__, url_prefix="/api")
FULL_ACCESS = (SUPER_ADMIN, DIRECTOR)
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ------------------------------------------------------------------ scoping (department / company / assignment)
def _vacancy_ids_for_dept(code):
    return [v.id for v in Vacancy.query.all() if code in (v.eligible_departments or [])]


def students_scope(q, u):
    r = u.role_name
    if r in FULL_ACCESS:
        return q
    if r == TPO:
        return q.filter(Student.department_id == u.department_id) if u.department_id else q.filter(false())
    if r == COORDINATOR:
        return q.filter(Student.coordinator_id == u.id)
    if r == RECRUITER and u.company_id:
        sub = db.session.query(Application.student_id).join(Vacancy, Vacancy.id == Application.vacancy_id) \
            .filter(Vacancy.company_id == u.company_id)
        return q.filter(Student.id.in_(sub))
    return q.filter(false())


def _through_student(model):
    def scope(q, u):
        if u.role_name in FULL_ACCESS:
            return q
        if u.role_name == RECRUITER:
            return q.filter(false()) if model is not Application else \
                q.filter(Application.vacancy_id.in_(db.session.query(Vacancy.id).filter(Vacancy.company_id == u.company_id)))
        ids = students_scope(db.session.query(Student.id), u)
        return q.filter(model.student_id.in_(ids))
    return scope


def companies_scope(q, u):
    if u.role_name in FULL_ACCESS:
        return q
    if u.role_name == RECRUITER and u.company_id:
        return q.filter(Company.id == u.company_id)
    return q.filter(false())


def vacancies_scope(q, u):
    r = u.role_name
    if r in FULL_ACCESS:
        return q
    if r == RECRUITER and u.company_id:
        return q.filter(Vacancy.company_id == u.company_id)
    live = Vacancy.status.in_(["Approved", "Active", "Closed"])
    if r == TPO and u.department and u.department.code:
        return q.filter(live, Vacancy.id.in_(_vacancy_ids_for_dept(u.department.code) or [-1]))
    if r == COORDINATOR:
        return q.filter(live)
    return q.filter(false())


def drives_scope(q, u):
    r = u.role_name
    if r in FULL_ACCESS or r == COORDINATOR:
        return q
    if r == RECRUITER and u.company_id:
        return q.filter(RecruitmentDrive.company_id == u.company_id)
    if r == TPO and u.department:
        ids = _vacancy_ids_for_dept(u.department.code) or [-1]
        return q.filter((RecruitmentDrive.vacancy_id.is_(None)) | RecruitmentDrive.vacancy_id.in_(ids))
    return q.filter(false())


def open_scope(q, u):  # director / admin only resources (permission already enforced)
    return q if u.role_name in FULL_ACCESS else q.filter(false())


def departments_scope(q, u):
    if u.role_name in FULL_ACCESS:
        return q
    if u.role_name == TPO:
        return q.filter(Department.id == u.department_id)
    return q


# ------------------------------------------------------------------ resource description
class Res:
    def __init__(self, key, model, fields, required=(), choices=None, ranges=None, search=(), filters=(),
                 scope=open_scope, extra=None, order=None, validate=None, writable=None, redact=None,
                 after_save=None, before_delete=None, create_ok=None):
        self.key, self.model, self.fields = key, model, list(fields)
        self.required, self.choices, self.ranges = set(required), choices or {}, ranges or {}
        self.search, self.filters, self.scope = search, filters, scope
        self.extra, self.order, self.validate = extra, order, validate
        self._writable, self.redact, self.after_save = writable, redact, after_save
        self.before_delete, self.create_ok = before_delete, create_ok

    def writable(self, user, creating):
        return self._writable(user, creating) if self._writable else self.fields

    def dump(self, obj, user):
        d = obj.to_dict()
        if self.extra:
            d.update(self.extra(obj))
        if self.redact:
            d = self.redact(d, user)
        return d


def coerce(col, v):
    if v is None or (isinstance(v, str) and v.strip() == ""):
        if col.nullable:
            return None
        if isinstance(col.type, (Integer, Float)) or col.type.__class__.__name__ == "Boolean":
            raise ValueError
        return ""
    t = col.type
    if isinstance(t, Boolean):
        if isinstance(v, bool):
            return v
        raise ValueError
    if isinstance(t, Integer):
        return int(v)
    if isinstance(t, Float):
        return float(v)
    if isinstance(t, Date):
        return date.fromisoformat(str(v)[:10])
    if t.__class__.__name__ == "JSON":
        if isinstance(v, str):
            v = [x.strip() for x in v.split(",") if x.strip()]
        if not isinstance(v, (list, dict)):
            raise ValueError
        return v
    s = str(v).strip()
    if getattr(t, "length", None):
        s = s[: t.length]
    return s


def write_fields(res, obj, data, user, creating):
    errors = {}
    cols = res.model.__table__.columns
    for f in res.writable(user, creating):
        k = camel(f)
        if k not in data:
            if creating and f in res.required and getattr(obj, f) in (None, ""):
                errors[k] = "Required"
            continue
        try:
            v = coerce(cols[f], data[k])
        except (ValueError, TypeError):
            errors[k] = "Invalid value"
            continue
        if f in res.required and v in (None, ""):
            errors[k] = "Required"
            continue
        if f in res.choices and v not in res.choices[f] and v is not None:
            errors[k] = "Choose one of: " + ", ".join(res.choices[f])
            continue
        if f in res.ranges and v is not None and not (res.ranges[f][0] <= v <= res.ranges[f][1]):
            errors[k] = f"Must be between {res.ranges[f][0]} and {res.ranges[f][1]}"
            continue
        setattr(obj, f, v)
    if errors:
        raise ApiError("Please correct the highlighted fields.", 422, errors)
    if res.validate:
        res.validate(obj, g.user, creating)


# ------------------------------------------------------------------ per-resource rules
def _name(u):
    return u.full_name if u else None


def students_extra(s):
    c = db.session.get(User, s.coordinator_id) if s.coordinator_id else None
    return {"departmentName": s.department.name, "departmentCode": s.department.code, "coordinatorName": _name(c)}


def students_redact(d, u):
    if u.role_name != RECRUITER:
        return d
    keep = ("id", "rollNo", "name", "departmentName", "departmentCode", "batch", "cgpa", "activeBacklogs",
            "historyBacklogs", "skills", "preferredDomain")
    return {k: d[k] for k in keep if k in d}


def students_validate(s, u, creating):
    errs = {}
    if s.email and not EMAIL_RE.match(s.email):
        errs["email"] = "Invalid e-mail"
    if not db.session.get(Department, s.department_id or 0):
        errs["departmentId"] = "Unknown department"
    if u.role_name == TPO and s.department_id != u.department_id:
        raise ApiError("You can only manage students of your own department.", 403, code="forbidden")
    if s.coordinator_id:
        c = db.session.get(User, s.coordinator_id)
        if not c or c.role_name != COORDINATOR or c.status != "active":
            errs["coordinatorId"] = "Select an active student coordinator"
    if errs:
        raise ApiError("Please correct the highlighted fields.", 422, errs)


def companies_writable(u, creating):
    if u.role_name == RECRUITER:
        return ["industry", "location", "contact_name", "contact_designation", "contact_email", "contact_phone",
                "website", "about"]
    return list(COMPANY_FIELDS)


def companies_create_ok(u):
    return u.role_name != RECRUITER


def vacancies_extra(v):
    n = Application.query.filter_by(vacancy_id=v.id).count()
    sl = Application.query.filter(Application.vacancy_id == v.id,
                                  Application.stage.in_(["Shortlisted", "Aptitude", "Technical", "HR", "Selected"])).count()
    return {"companyName": v.company.name, "applicationsCount": n, "shortlistedCount": sl}


def vacancies_writable(u, creating):
    f = list(VACANCY_FIELDS)
    if u.role_name == RECRUITER:
        f.remove("source")
        if creating:
            f.append("company_id")
    else:
        f.append("company_id")
    return f


def vacancies_validate(v, u, creating):
    v.status = v.status or "Draft"
    if u.role_name == RECRUITER:
        if not u.company_id:
            raise ApiError("Your account is not linked to a company.", 403, code="forbidden")
        v.company_id = u.company_id
        if not creating and getattr(v, "_was_live", False):
            v.status = "Pending Verification"  # any edit to a live vacancy requires re-verification
        elif v.status not in ("Draft", "Pending Verification"):
            raise ApiError("Recruiters can only save Draft or Pending Verification vacancies.", 403, code="forbidden")
        v.submitted_by_id = u.id
    elif v.status in ("Approved", "Active") and not can(u, "vacancies:verify"):
        raise ApiError("You may not approve vacancies.", 403, code="forbidden")
    if not db.session.get(Company, v.company_id or 0):
        raise ApiError("Please correct the highlighted fields.", 422, {"companyId": "Unknown company"})
    bad = [c for c in (v.eligible_departments or []) if not Department.query.filter_by(code=c).first()]
    if bad:
        raise ApiError("Please correct the highlighted fields.", 422, {"eligibleDepartments": "Unknown department code: " + ", ".join(bad)})


def drives_extra(d):
    return {"companyName": d.company.name}


def drives_validate(d, u, creating):
    if not db.session.get(Company, d.company_id or 0):
        raise ApiError("Please correct the highlighted fields.", 422, {"companyId": "Unknown company"})
    if d.vacancy_id:
        v = db.session.get(Vacancy, d.vacancy_id)
        if not v or v.company_id != d.company_id:
            raise ApiError("Please correct the highlighted fields.", 422, {"vacancyId": "Vacancy must belong to the selected company"})


def apps_extra(a):
    return {"studentName": a.student.name, "rollNo": a.student.roll_no, "departmentCode": a.student.department.code,
            "cgpa": a.student.cgpa, "vacancyTitle": a.vacancy.title, "companyName": a.vacancy.company.name}


def apps_redact(d, u):
    if u.role_name == RECRUITER:
        d = {k: v for k, v in d.items() if k not in ("updatedById",)}
    return d


def apps_writable(u, creating):
    if creating:
        return ["student_id", "vacancy_id", "stage", "score", "remarks"]
    return ["stage", "score", "remarks"]


def apps_create_ok(u):
    return u.role_name != RECRUITER


def apps_validate(a, u, creating):
    if creating:
        s = students_scope(Student.query, u).filter(Student.id == a.student_id).first()
        v = vacancies_scope(Vacancy.query, u).filter(Vacancy.id == a.vacancy_id).first()
        if not s:
            raise ApiError("Student not found in your scope.", 404)
        if not v:
            raise ApiError("Vacancy not found in your scope.", 404)
        if v.status not in ("Approved", "Active"):
            raise ApiError("Applications can only be created for approved vacancies.", 422, {"vacancyId": "Vacancy is not open"})
        why = []
        if s.cgpa < (v.min_cgpa or 0):
            why.append(f"CGPA below minimum {v.min_cgpa}")
        if s.active_backlogs > (v.max_backlogs or 0):
            why.append("too many active backlogs")
        if s.department.code not in (v.eligible_departments or []):
            why.append("department not eligible")
        if why:
            raise ApiError("Student is not eligible: " + "; ".join(why) + ".", 422, {"studentId": "Not eligible"})
    a.updated_by_id = u.id


def internships_extra(i):
    return {"studentName": i.student.name, "rollNo": i.student.roll_no, "departmentCode": i.student.department.code}


def student_link_validate(model_label):
    def v(obj, u, creating):
        if not students_scope(Student.query, u).filter(Student.id == obj.student_id).first():
            raise ApiError("Student not found in your scope.", 404)
    return v


def internship_after(i, creating, user):
    s = i.student
    mapping = {"Ongoing": "Ongoing", "Completed": "Completed", "PPO Converted": "PPO Converted"}
    if i.status in mapping:
        s.internship_status = mapping[i.status]


def placements_extra(p):
    return {"studentName": p.student.name, "rollNo": p.student.roll_no, "departmentCode": p.student.department.code,
            "companyName": p.company.name, "tier": p.company.tier}


def placements_validate(p, u, creating):
    if not db.session.get(Student, p.student_id or 0):
        raise ApiError("Please correct the highlighted fields.", 422, {"studentId": "Unknown student"})
    if not db.session.get(Company, p.company_id or 0):
        raise ApiError("Please correct the highlighted fields.", 422, {"companyId": "Unknown company"})


def placements_after(p, creating, user):
    if creating and not p.offer_ref:
        p.offer_ref = f"OFR-{utcnow().year}-{p.id:05d}"
    if p.offer_accepted:
        p.student.status = "Placed"
    elif p.student.status != "Placed":
        p.student.status = "In Process"
    c = p.company
    if p.signed_date and (not c.last_drive_date or p.signed_date > c.last_drive_date):
        c.last_drive_date = p.signed_date


def placements_before_delete(p):
    others = PlacementOffer.query.filter(PlacementOffer.student_id == p.student_id, PlacementOffer.id != p.id,
                                         PlacementOffer.offer_accepted.is_(True)).count()
    if not others:
        p.student.status = "Unplaced"


def outreach_extra(o):
    return {"companyName": o.company.name}


def departments_validate(d, u, creating):
    d.code = (d.code or "").upper()


STUDENT_FIELDS = ["roll_no", "name", "email", "phone", "department_id", "batch", "cgpa", "active_backlogs",
                  "history_backlogs", "skills", "status", "internship_status", "preferred_domain", "coordinator_id"]
COMPANY_FIELDS = ["name", "industry", "tier", "location", "contact_name", "contact_designation", "contact_email",
                  "contact_phone", "mou_status", "website", "about", "last_drive_date"]
VACANCY_FIELDS = ["title", "job_type", "ctc_lpa", "stipend_per_month", "locations", "eligible_departments",
                  "min_cgpa", "max_backlogs", "application_deadline", "drive_date", "status", "openings",
                  "description", "source"]
APP_STAGES = ["Applied", "Shortlisted", "Aptitude", "Technical", "HR", "Selected", "Rejected", "Withdrawn"]

RESOURCES = {
    "students": Res("students", Student, STUDENT_FIELDS, required={"roll_no", "name", "email", "department_id", "batch"},
                    choices={"status": ["Placed", "In Process", "Unplaced", "Opted Out"],
                             "internship_status": ["None", "Ongoing", "Completed", "PPO Converted"]},
                    ranges={"cgpa": (0, 10), "active_backlogs": (0, 50), "history_backlogs": (0, 50)},
                    search=("name", "roll_no", "email"), filters=("department_id", "status", "batch"),
                    scope=students_scope, extra=students_extra, redact=students_redact, validate=students_validate,
                    order=Student.name),
    "companies": Res("companies", Company, COMPANY_FIELDS, required={"name"},
                     choices={"tier": ["Super Dream (>20 LPA)", "Dream (12-20 LPA)", "Core Corporate", "Mass Recruiter"],
                              "mou_status": ["Signed", "In Discussion", "Pending Renewal", "None"]},
                     search=("name", "industry", "location"), filters=("tier", "mou_status"), scope=companies_scope,
                     writable=companies_writable, create_ok=companies_create_ok, order=Company.name),
    "vacancies": Res("vacancies", Vacancy, VACANCY_FIELDS, required={"title", "company_id"},
                     choices={"job_type": ["Full-Time", "Internship + PPO", "Internship Only"],
                              "status": ["Draft", "Pending Verification", "Approved", "Active", "Closed", "Archived"]},
                     ranges={"ctc_lpa": (0, 500), "min_cgpa": (0, 10), "max_backlogs": (0, 50), "openings": (1, 10000)},
                     search=("title",), filters=("status", "company_id", "job_type"), scope=vacancies_scope,
                     extra=vacancies_extra, writable=vacancies_writable, validate=vacancies_validate,
                     order=Vacancy.created_at.desc()),
    "outreach": Res("outreach", Outreach, ["company_id", "channel", "subject", "message", "status", "next_followup_date"],
                    required={"company_id", "subject"},
                    choices={"channel": ["Email", "Call", "Meeting", "LinkedIn"],
                             "status": ["Draft", "Sent", "Replied", "Follow-up", "Closed"]},
                    search=("subject",), filters=("status", "company_id", "channel"), extra=outreach_extra,
                    order=Outreach.created_at.desc()),
    "drives": Res("drives", RecruitmentDrive, ["title", "company_id", "vacancy_id", "date", "mode", "venue", "stage",
                                               "status", "registered_count", "shortlisted_count", "selected_count", "notes"],
                  required={"title", "company_id", "date"},
                  choices={"mode": ["On-Campus", "Virtual", "Hybrid"],
                           "stage": ["Pre-Placement Talk", "Online Aptitude Test", "Technical Round 1", "Technical Round 2",
                                     "Group Discussion", "HR Interview", "Final Offers"],
                           "status": ["Upcoming", "Live Today", "Completed", "Postponed"]},
                  search=("title", "venue"), filters=("status", "company_id", "mode"), scope=drives_scope,
                  extra=drives_extra, validate=drives_validate, order=RecruitmentDrive.date.desc()),
    "applications": Res("applications", Application, ["student_id", "vacancy_id", "stage", "score", "remarks"],
                        required={"student_id", "vacancy_id"}, choices={"stage": APP_STAGES},
                        ranges={"score": (0, 100)}, filters=("stage", "vacancy_id", "student_id"),
                        scope=_through_student(Application), extra=apps_extra, redact=apps_redact,
                        writable=apps_writable, validate=apps_validate, create_ok=apps_create_ok,
                        order=Application.updated_at.desc()),
    "internships": Res("internships", Internship,
                       ["student_id", "company_name", "stipend_per_month", "duration_months", "start_date", "end_date",
                        "mentor_name", "mentor_email", "progress_percent", "ppo_offered", "ppo_ctc_lpa",
                        "evaluation_grade", "status"],
                       required={"student_id", "company_name"},
                       choices={"status": ["Ongoing", "PPO Converted", "Completed", "Terminated"]},
                       ranges={"progress_percent": (0, 100), "duration_months": (1, 24)}, filters=("status", "student_id"),
                       search=("company_name",), scope=_through_student(Internship), extra=internships_extra,
                       validate=student_link_validate("internship"), after_save=internship_after,
                       order=Internship.created_at.desc()),
    "placements": Res("placements", PlacementOffer,
                      ["student_id", "company_id", "designation", "ctc_lpa", "base_lpa", "joining_date", "location",
                       "offer_accepted", "verified", "signed_date"],
                      required={"student_id", "company_id", "designation", "ctc_lpa"}, ranges={"ctc_lpa": (0, 500), "base_lpa": (0, 500)},
                      search=("designation", "offer_ref", "location"), filters=("company_id", "student_id", "offer_accepted"),
                      scope=_through_student(PlacementOffer), extra=placements_extra, validate=placements_validate,
                      after_save=placements_after, before_delete=placements_before_delete,
                      order=PlacementOffer.created_at.desc()),
    "departments": Res("departments", Department, ["code", "name", "hod_name", "intake"], required={"code", "name"},
                       ranges={"intake": (0, 5000)}, search=("name", "code"), scope=departments_scope,
                       validate=departments_validate, order=Department.name),
}


# ------------------------------------------------------------------ endpoint factories
def _scoped_get(res, rid):
    obj = res.scope(res.model.query, g.user).filter(res.model.id == rid).first()
    if not obj:
        raise ApiError("Record not found.", 404)
    return obj


def _commit_or_conflict():
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        raise ApiError("A record with the same unique value already exists, or a linked record is missing.", 409)


def register(res: Res):
    k = res.key

    @bp.get(f"/{k}", endpoint=f"{k}_list")
    @require_auth(f"{k}:read")
    def list_():
        q = res.scope(res.model.query, g.user)
        s = request.args.get("q", "").strip()
        if s and res.search:
            like = f"%{s}%"
            from sqlalchemy import or_
            q = q.filter(or_(*[getattr(res.model, c).ilike(like) for c in res.search]))
        for f in res.filters:
            val = request.args.get(camel(f))
            if val not in (None, ""):
                col = getattr(res.model, f)
                if val in ("true", "false"):
                    val = val == "true"
                q = q.filter(col == val)
        if res.order is not None:
            q = q.order_by(res.order)
        page = max(int(request.args.get("page", 1) or 1), 1)
        size = min(max(int(request.args.get("pageSize", 100) or 100), 1), 1000)
        total = q.count()
        items = q.offset((page - 1) * size).limit(size).all()
        return jsonify({"items": [res.dump(o, g.user) for o in items], "total": total, "page": page, "pageSize": size})

    @bp.get(f"/{k}/<int:rid>", endpoint=f"{k}_get")
    @require_auth(f"{k}:read")
    def get_(rid):
        return jsonify(res.dump(_scoped_get(res, rid), g.user))

    @bp.post(f"/{k}", endpoint=f"{k}_create")
    @require_auth(f"{k}:write")
    def create_():
        if res.create_ok and not res.create_ok(g.user):
            raise ApiError("Your role cannot create this record type.", 403, code="forbidden")
        data = request.get_json(silent=True) or {}
        obj = res.model()
        if k == "vacancies" and g.user.role_name == RECRUITER:
            obj.company_id = g.user.company_id  # recruiters always post for their own company
        write_fields(res, obj, data, g.user, True)
        db.session.add(obj)
        try:
            db.session.flush()
            if res.after_save:
                res.after_save(obj, True, g.user)
        except IntegrityError:
            db.session.rollback()
            raise ApiError("A record with the same unique value already exists.", 409)
        _commit_or_conflict()
        audit(f"Created {k}", k, obj.id, str(getattr(obj, "name", None) or getattr(obj, "title", "") or ""))
        return jsonify(res.dump(obj, g.user)), 201

    @bp.put(f"/{k}/<int:rid>", endpoint=f"{k}_update")
    @require_auth(f"{k}:write")
    def update_(rid):
        obj = _scoped_get(res, rid)
        if k == "vacancies":
            obj._was_live = obj.status in ("Approved", "Active")
        data = request.get_json(silent=True) or {}
        write_fields(res, obj, data, g.user, False)
        if res.after_save:
            res.after_save(obj, False, g.user)
        _commit_or_conflict()
        audit(f"Updated {k}", k, obj.id, ", ".join(sorted(data.keys()))[:200])
        return jsonify(res.dump(obj, g.user))

    @bp.delete(f"/{k}/<int:rid>", endpoint=f"{k}_delete")
    @require_auth(f"{k}:delete")
    def delete_(rid):
        obj = _scoped_get(res, rid)
        if res.before_delete:
            res.before_delete(obj)
        label = str(getattr(obj, "name", None) or getattr(obj, "title", "") or obj.id)
        db.session.delete(obj)
        _commit_or_conflict()
        audit(f"Deleted {k}", k, rid, label)
        return jsonify({"ok": True})


for _r in RESOURCES.values():
    register(_r)


# ------------------------------------------------------------------ lookups
@bp.get("/lookups")
@require_auth()
def lookups():
    u = g.user
    out = {"departments": [{"id": d.id, "code": d.code, "label": d.name} for d in Department.query.order_by(Department.name)]}
    if can(u, "companies:read") or can(u, "vacancies:read") or can(u, "placements:write") or can(u, "outreach:read") or can(u, "drives:write"):
        qc = Company.query.order_by(Company.name)
        qc = qc if u.role_name != RECRUITER else companies_scope(qc, u)
        if u.role_name != TPO and u.role_name != COORDINATOR:
            out["companies"] = [{"id": c.id, "label": c.name} for c in qc]
    if can(u, "students:read"):
        out["students"] = [{"id": s.id, "label": f"{s.name} ({s.roll_no})", "departmentId": s.department_id}
                           for s in students_scope(Student.query, u).order_by(Student.name).limit(2000)]
    if can(u, "vacancies:read"):
        out["vacancies"] = [{"id": v.id, "label": f"{v.title} – {v.company.name}", "companyId": v.company_id, "status": v.status}
                            for v in vacancies_scope(Vacancy.query, u).order_by(Vacancy.title).limit(2000)]
    if can(u, "students:write"):
        out["coordinators"] = [{"id": c.id, "label": c.full_name} for c in User.query.all()
                               if c.role_name == COORDINATOR and c.status == "active"]
    return jsonify(out)


# ------------------------------------------------------------------ vacancy workflow
@bp.post("/vacancies/<int:vid>/submit")
@require_auth("vacancies:write")
def submit_vacancy(vid):
    v = _scoped_get(RESOURCES["vacancies"], vid)
    if v.status != "Draft":
        raise ApiError("Only Draft vacancies can be submitted for verification.", 409)
    v.status = "Pending Verification"
    db.session.commit()
    audit("Submitted vacancy for verification", "vacancies", v.id, v.title)
    return jsonify(RESOURCES["vacancies"].dump(v, g.user))


@bp.post("/vacancies/<int:vid>/review")
@require_auth("vacancies:verify")
def review_vacancy(vid):
    v = _scoped_get(RESOURCES["vacancies"], vid)
    d = request.get_json(silent=True) or {}
    decision = d.get("decision")
    note = str(d.get("note", ""))[:500]
    if v.status != "Pending Verification":
        raise ApiError("This vacancy is not awaiting verification.", 409)
    if decision not in ("approve", "return"):
        raise ApiError("Decision must be approve or return.", 400)
    if decision == "return" and len(note) < 5:
        raise ApiError("Give the company a reason when returning a vacancy.", 422, {"note": "Required"})
    v.status = "Approved" if decision == "approve" else "Draft"
    db.session.add(VacancyVerification(vacancy_id=v.id, decision="Approved" if decision == "approve" else "Returned",
                                       note=note, reviewer_id=g.user.id, reviewer_name=g.user.full_name))
    # notify the submitter
    if v.submitted_by_id:
        db.session.add(Notification(user_id=v.submitted_by_id, type="approval", sender_id=g.user.id,
                                    title=f"Vacancy {'approved' if decision == 'approve' else 'returned'}: {v.title}",
                                    message=note or ("Your vacancy has been verified." if decision == "approve" else "")))
    db.session.commit()
    audit(f"Vacancy {decision}", "vacancies", v.id, v.title + (f" – {note}" if note else ""))
    return jsonify(RESOURCES["vacancies"].dump(v, g.user))


@bp.get("/vacancy-verifications")
@require_auth("vacancies:verify")
def verification_history():
    rows = VacancyVerification.query.order_by(VacancyVerification.created_at.desc()).limit(200).all()
    out = []
    for r in rows:
        v = db.session.get(Vacancy, r.vacancy_id)
        d = r.to_dict()
        d["vacancyTitle"] = v.title if v else "(deleted)"
        d["companyName"] = v.company.name if v else ""
        out.append(d)
    return jsonify({"items": out})


@bp.post("/vacancies/import")
@require_auth("vacancies:import")
def import_vacancies():
    """CSV import. dry_run=true validates only; otherwise valid rows are created as Draft (source=Import)."""
    f = request.files.get("file")
    if not f or not (f.filename or "").lower().endswith(".csv"):
        raise ApiError("Upload a .csv file.", 400)
    raw = f.read(2_000_000)
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ApiError("File must be UTF-8 encoded.", 400)
    rows = list(csv.DictReader(io.StringIO(text)))
    if not rows:
        raise ApiError("The file has no data rows.", 400)
    if len(rows) > 500:
        raise ApiError("Maximum 500 rows per import.", 400)
    dry = request.form.get("dryRun", "true") == "true"
    companies = {c.name.lower(): c for c in Company.query.all()}
    codes = {d.code for d in Department.query.all()}
    result, created = [], 0
    for i, r in enumerate(rows, start=2):
        r = {(k or "").strip().lower(): (v or "").strip() for k, v in r.items()}
        errs = []
        co = companies.get(r.get("company", "").lower())
        if not r.get("title"):
            errs.append("title missing")
        if not co:
            errs.append(f"company '{r.get('company', '')}' not found")
        try:
            ctc = float(r.get("ctc_lpa") or 0)
            cg = float(r.get("min_cgpa") or 0)
            ob = int(r.get("openings") or 1)
        except ValueError:
            errs.append("numeric field invalid")
            ctc = cg = 0
            ob = 1
        depts = [x.strip().upper() for x in (r.get("departments", "")).replace(";", ",").split(",") if x.strip()]
        if set(depts) - codes:
            errs.append("unknown department code(s): " + ", ".join(sorted(set(depts) - codes)))
        dl = None
        if r.get("deadline"):
            try:
                dl = date.fromisoformat(r["deadline"])
            except ValueError:
                errs.append("deadline must be YYYY-MM-DD")
        jt = r.get("job_type") or "Full-Time"
        if jt not in ("Full-Time", "Internship + PPO", "Internship Only"):
            errs.append("invalid job_type")
        result.append({"row": i, "title": r.get("title"), "company": r.get("company"), "errors": errs})
        if not errs and not dry:
            db.session.add(Vacancy(title=r["title"][:160], company_id=co.id, job_type=jt, ctc_lpa=ctc, min_cgpa=cg,
                                   openings=ob, eligible_departments=depts, application_deadline=dl,
                                   locations=[x.strip() for x in r.get("locations", "").split(";") if x.strip()],
                                   description=r.get("description", "")[:4000], status="Draft", source="Import",
                                   submitted_by_id=g.user.id))
            created += 1
    if not dry:
        db.session.commit()
        audit("Imported vacancies", "vacancies", "", f"{created} created of {len(rows)} rows")
    return jsonify({"dryRun": dry, "total": len(rows), "valid": sum(1 for x in result if not x["errors"]),
                    "created": created, "rows": result})


# ------------------------------------------------------------------ department statistics
@bp.get("/departments-stats")
@require_auth("departments:read")
def department_stats():
    out = []
    for d in departments_scope(Department.query, g.user).order_by(Department.name):
        studs = Student.query.filter_by(department_id=d.id).all()
        offers = PlacementOffer.query.join(Student).filter(Student.department_id == d.id, PlacementOffer.offer_accepted.is_(True)).all()
        placed_ids = {o.student_id for o in offers}
        out.append({**d.to_dict(), "totalStudents": len(studs), "placedStudents": len(placed_ids),
                    "placementRate": round(100 * len(placed_ids) / len(studs), 1) if studs else 0,
                    "avgCtcLpa": round(sum(o.ctc_lpa for o in offers) / len(offers), 2) if offers else 0,
                    "highestCtcLpa": max((o.ctc_lpa for o in offers), default=0)})
    return jsonify({"items": out})
