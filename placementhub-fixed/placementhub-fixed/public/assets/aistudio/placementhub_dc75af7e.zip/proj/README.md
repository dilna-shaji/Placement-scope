# PlacementHub – College Placement Management System

React 19 + TypeScript + Tailwind v4 + Recharts + Motion frontend, Flask + SQLAlchemy + MySQL 8 backend.
One login page, administrator-approved roles, server-enforced RBAC, 20 working modules.

## Structure
```
placementhub/
├─ src/                      React app
│  ├─ components/layout/     AppShell, Sidebar (independent scroll), TopBar
│  ├─ components/auth/       Login, Request account, Forgot/Reset, Forced password change, CAPTCHA
│  ├─ components/ui/         UI kit + generic ResourcePage (CRUD tables/forms)
│  └─ components/modules/    the 20 modules (1_Dashboard … 20_SystemSettings)
├─ backend/
│  ├─ app/permissions.py     CENTRAL role → permission configuration
│  ├─ app/auth.py            login, sessions, CSRF, lockout, reset, account requests
│  ├─ app/resources.py       permission-checked, department/company/assignment-scoped CRUD
│  ├─ app/admin.py           users, requests, roles, security console, settings, audit, notifications
│  ├─ app/insights.py        role dashboards, analytics, CSV/XLSX export
│  ├─ app/files.py           validated document upload
│  ├─ migrations/            Flask-Migrate (24 tables)
│  └─ tests/                 pytest (34 tests) + e2e_browser.py (Playwright, 54 checks)
```

## Windows 11 setup (PowerShell)
Prerequisites: Node.js 20+, Python 3.11+, MySQL 8.

### 1. Database
```sql
CREATE DATABASE placementhub CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER 'placementhub_user'@'localhost' IDENTIFIED BY 'choose-a-strong-password';
GRANT ALL ON placementhub.* TO 'placementhub_user'@'localhost';
```

### 2. Backend
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env        # then edit .env: SECRET_KEY (32+ random chars), DATABASE_URL
$env:FLASK_APP = "wsgi.py"
flask db upgrade              # creates all tables
flask seed-rbac               # roles, permissions, 5 specialisation departments
flask create-superadmin       # prompts for e-mail, name, password – the ONLY way to bootstrap
flask run --port 5000
```
Optional, clearly labelled sample records (no user accounts are ever created): `flask seed-sample`

### 3. Frontend
```powershell
cd ..            # project root
npm install
npm run dev      # http://localhost:3000  (proxies /api to http://127.0.0.1:5000)
```
Sign in with the Super Admin you created, choose portal role **Super Admin**.
Create other users in **Users & Roles**, or let people submit **Request new account** and approve them there.

## CAPTCHA
* `CAPTCHA_PROVIDER=local` – server-verified one-time image challenge (development/testing only; the backend refuses to start in production with it).
* `CAPTCHA_PROVIDER=turnstile` – set `TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET_KEY`; the secret never reaches the browser.

## Password reset e-mail
`MAIL_MODE=console` prints the reset link in the Flask log (development). Use `MAIL_MODE=smtp` plus `SMTP_*` for real mail.

## Tests
```powershell
cd backend; pytest -q                     # 34 API tests: auth, RBAC, scoping, workflows
# Browser e2e (needs running servers + `pip install playwright; playwright install chromium`, SQLite dev DB)
python tests/e2e_browser.py
```
`e2e_browser.py` was written against a throw-away SQLite database at `/tmp/ph_e2e.db`; adjust `DB` at its top for your machine.

## Security model (summary)
* Argon2id hashes; temporary passwords generated with `secrets`, shown once, change forced at first login.
* Opaque session token in an HttpOnly cookie (hash stored server-side), idle + absolute expiry, per-session CSRF token.
* Failed-login counter with progressive lockout, plus per-IP throttling; CAPTCHA verified server-side before credentials.
* The portal-role dropdown is an intent check only; the role stored by an administrator decides everything.
* Every endpoint goes through `require_auth(permission)`; data is scoped by department / company / assignment on the server.
* Audit log for logins, denials, role and permission changes, approvals, exports.

## Known limits
* Verified against SQLite in this build environment; MySQL 8 is the target and the schema uses only portable types, but run `flask db upgrade` on your server and the pytest suite against it before go-live.
* Dark mode from the original prototype was removed.
