import { useRef, useState } from 'react';
import { CheckCircle2, FileUp, Download, XCircle } from 'lucide-react';
import { api, ApiError } from '../../../lib/api';
import { useUI } from '../../../context/UIContext';
import { Badge, Button, Card, PageHeader, downloadBlob } from '../../ui/kit';

interface Res { dryRun: boolean; total: number; valid: number; created: number; rows: { row: number; title: string; company: string; errors: string[] }[] }
const TEMPLATE = 'title,company,job_type,ctc_lpa,min_cgpa,openings,departments,locations,deadline,description\nMarketing Associate,Existing Company Name,Full-Time,8.5,6.5,5,MKT;BA,Mumbai;Pune,2026-12-20,Role summary\n';

export default function OpportunityImportView() {
  const { toast } = useUI();
  const input = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null); const [res, setRes] = useState<Res | null>(null); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [drag, setDrag] = useState(false);
  const run = async (dry: boolean) => {
    if (!file) return; setBusy(true); setErr('');
    const fd = new FormData(); fd.append('file', file); fd.append('dryRun', String(dry));
    try { const r = await api.upload<Res>('/api/vacancies/import', fd); setRes(r); if (!dry) { toast(`${r.created} vacancies imported as drafts`); setFile(null); } }
    catch (e) { setErr((e as ApiError).message); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-7">
      <PageHeader title="Opportunity collection & data import" subtitle="Bring in vacancies collected from company mailers or spreadsheets. Rows are validated first; imports land as Drafts for review."
        actions={<Button variant="secondary" onClick={() => downloadBlob(new Blob([TEMPLATE], { type: 'text/csv' }), 'vacancy_import_template.csv')}><Download className="w-4 h-4" />Download template</Button>} />
      <Card>
        <div onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={(e) => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) { setFile(f); setRes(null); } }}
          onClick={() => input.current?.click()} className={`cursor-pointer rounded-2xl border-2 border-dashed p-10 text-center transition ${drag ? 'border-violet bg-violet/8' : 'border-line hover:border-violet/60 hover:bg-canvas'}`}>
          <FileUp className="w-9 h-9 mx-auto text-violet" /><p className="font-bold text-[17px] mt-3">{file ? file.name : 'Drop a CSV file here, or click to browse'}</p><p className="text-mute text-[14px]">UTF-8 CSV · up to 500 rows · company must already exist</p>
          <input ref={input} type="file" accept=".csv" hidden onChange={(e) => { setFile(e.target.files?.[0] ?? null); setRes(null); }} />
        </div>
        {err && <div role="alert" className="mt-4 rounded-xl bg-coral/10 border border-coral/30 text-[#9e2f1b] px-4 py-3 text-[14px]">{err}</div>}
        <div className="flex gap-3 mt-5"><Button variant="secondary" disabled={!file} loading={busy} onClick={() => run(true)}>Validate file</Button><Button disabled={!file || !res || res.valid === 0 || !res.dryRun} loading={busy} onClick={() => run(false)}>Import {res?.valid ?? 0} valid row(s)</Button></div>
      </Card>
      {res && (
        <Card padded={false} className="overflow-hidden">
          <div className="p-5 border-b border-line flex flex-wrap gap-3 items-center"><h3 className="font-bold text-[17px]">{res.dryRun ? 'Validation result' : 'Import complete'}</h3><Badge tone="aqua">{res.valid} valid</Badge><Badge tone="coral">{res.total - res.valid} with errors</Badge>{!res.dryRun && <Badge tone="lime">{res.created} created</Badge>}</div>
          <div className="overflow-x-auto max-h-[420px]"><table className="tbl w-full min-w-[640px]"><thead><tr><th>Row</th><th>Title</th><th>Company</th><th>Result</th></tr></thead>
            <tbody>{res.rows.map((r) => <tr key={r.row}><td>{r.row}</td><td className="font-semibold">{r.title || '—'}</td><td>{r.company}</td><td>{r.errors.length ? <span className="flex items-start gap-2 text-[#9e2f1b]"><XCircle className="w-4 h-4 mt-0.5 shrink-0" />{r.errors.join('; ')}</span> : <span className="flex items-center gap-2 text-[#0e7a7c]"><CheckCircle2 className="w-4 h-4" />OK</span>}</td></tr>)}</tbody></table></div>
        </Card>)}
    </div>
  );
}
