import { useState } from 'react';
import { CheckCircle2, Undo2 } from 'lucide-react';
import { api, ApiError } from '../../../lib/api';
import { useUI } from '../../../context/UIContext';
import { Badge, Button, Card, Empty, ErrorNote, Field, Modal, PageHeader, StatusBadge, TextArea, useFetch } from '../../ui/kit';
import { fmtDate, fmtDateTime } from '../../../lib/format';
import type { Page, Row } from '../../../types';
import { motion } from 'motion/react';

export default function VerificationApprovalView() {
  const { toast } = useUI();
  const q = useFetch<Page>('/api/vacancies?status=Pending Verification&pageSize=200');
  const h = useFetch<{ items: Row[] }>('/api/vacancy-verifications');
  const [sel, setSel] = useState<{ v: Row; mode: 'approve' | 'return' } | null>(null); const [note, setNote] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true); setErr('');
    try { await api.post(`/api/vacancies/${sel!.v.id}/review`, { decision: sel!.mode, note }); toast(sel!.mode === 'approve' ? 'Vacancy approved and published to eligible students' : 'Returned to the company with your note'); setSel(null); setNote(''); q.reload(); h.reload(); }
    catch (e) { setErr((e as ApiError).message); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-7">
      <PageHeader title="Vacancy verification & approval" subtitle="Check compensation, eligibility and company details before a vacancy becomes visible to students." />
      {q.error ? <ErrorNote message={q.error} onRetry={q.reload} /> : !q.data?.items.length ? <Empty title="Nothing waiting for review" text="Submitted vacancies appear here." /> : (
        <div className="grid xl:grid-cols-2 gap-5">{q.data.items.map((v, i) => (
          <motion.div key={v.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * .05 }}>
            <Card hover className="h-full flex flex-col">
              <div className="flex justify-between gap-3"><div><h3 className="font-extrabold text-[19px]">{v.title}</h3><p className="text-mute">{v.companyName} · {v.jobType}</p></div><p className="font-num font-extrabold text-[26px] text-indigo">{v.ctcLpa}<span className="text-[13px] text-mute"> LPA</span></p></div>
              <div className="grid grid-cols-2 gap-3 mt-4 text-[14px]">
                <div><p className="text-[12px] uppercase font-semibold text-mute">Eligibility</p><p>CGPA ≥ {v.minCgpa} · ≤ {v.maxBacklogs} backlogs</p></div>
                <div><p className="text-[12px] uppercase font-semibold text-mute">Deadline</p><p>{fmtDate(v.applicationDeadline)}</p></div>
                <div className="col-span-2 flex gap-1.5 flex-wrap">{(v.eligibleDepartments || []).map((d: string) => <Badge key={d} tone="violet">{d}</Badge>)}{!(v.eligibleDepartments || []).length && <Badge tone="coral">No department selected</Badge>}</div>
              </div>
              {v.description && <p className="text-[14px] text-ink/75 mt-3 line-clamp-3">{v.description}</p>}
              <div className="flex gap-3 mt-auto pt-5"><Button variant="success" onClick={() => { setSel({ v, mode: 'approve' }); setErr(''); }}><CheckCircle2 className="w-4 h-4" />Approve</Button><Button variant="secondary" onClick={() => { setSel({ v, mode: 'return' }); setErr(''); }}><Undo2 className="w-4 h-4" />Return for changes</Button></div>
            </Card></motion.div>))}</div>)}
      <Card padded={false} className="overflow-hidden"><div className="p-5 border-b border-line"><h3 className="font-bold text-[17px]">Decision history</h3></div>
        <div className="overflow-x-auto"><table className="tbl w-full min-w-[640px]"><thead><tr><th>Vacancy</th><th>Decision</th><th>Reviewer</th><th>Note</th><th>When</th></tr></thead>
          <tbody>{h.data?.items.map((r) => <tr key={r.id}><td><p className="font-semibold">{r.vacancyTitle}</p><p className="text-[13px] text-mute">{r.companyName}</p></td><td><StatusBadge value={r.decision === 'Approved' ? 'Approved' : 'Draft'} /> <span className="text-[13px] text-mute">{r.decision}</span></td><td>{r.reviewerName}</td><td className="max-w-[280px] truncate">{r.note || '—'}</td><td className="text-mute">{fmtDateTime(r.createdAt)}</td></tr>)}</tbody></table>
          {!h.data?.items.length && <p className="text-center text-mute py-8">No decisions recorded yet.</p>}</div></Card>
      <Modal open={!!sel} onClose={() => setSel(null)} title={sel?.mode === 'approve' ? 'Approve vacancy' : 'Return vacancy'} subtitle={sel?.v.title} width="max-w-lg"
        footer={<><Button variant="secondary" onClick={() => setSel(null)}>Cancel</Button><Button loading={busy} variant={sel?.mode === 'approve' ? 'primary' : 'danger'} onClick={go}>{sel?.mode === 'approve' ? 'Approve' : 'Return to company'}</Button></>}>
        {err && <div role="alert" className="mb-4 rounded-xl bg-coral/10 border border-coral/30 text-[#9e2f1b] px-4 py-3 text-[14px]">{err}</div>}
        <Field label={sel?.mode === 'return' ? 'What needs to change?' : 'Note (optional)'} required={sel?.mode === 'return'}><TextArea value={note} onChange={(e) => setNote(e.target.value)} /></Field></Modal>
    </div>
  );
}
