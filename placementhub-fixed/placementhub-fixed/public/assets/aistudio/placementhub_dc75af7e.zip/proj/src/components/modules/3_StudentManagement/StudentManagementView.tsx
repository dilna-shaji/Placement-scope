import { GraduationCap, CheckCircle2, Clock, Target } from 'lucide-react';
import { ResourcePage, type ResourceConfig } from '../../ui/ResourcePage';
import { StatusBadge, Badge } from '../../ui/kit';
import { useAuth } from '../../../context/AuthContext';
import { StatsRow, count } from '../shared';

export default function StudentManagementView() {
  const { user, can } = useAuth();
  const tpo = user!.role === 'department_tpo';
  const cfg: ResourceConfig = {
    resource: 'students', singular: 'Student', title: 'Student management',
    subtitle: tpo || user!.role === 'student_coordinator' ? 'Students within your assigned scope.' : user!.role === 'corporate_recruiter' ? 'Candidates who applied to your company (limited profile).' : 'Profiles, eligibility and placement status across all departments.',
    searchPlaceholder: 'Search name, roll number or e-mail…',
    defaults: { departmentId: tpo ? user!.departmentId : '', status: 'Unplaced', internshipStatus: 'None', activeBacklogs: 0, historyBacklogs: 0, cgpa: '' },
    filters: [{ name: 'departmentId', label: 'Department', lookup: 'departments' }, { name: 'status', label: 'Status', options: ['Placed', 'In Process', 'Unplaced', 'Opted Out'] }],
    fields: [
      { name: 'name', label: 'Full name', required: true }, { name: 'rollNo', label: 'Roll number', required: true, hint: 'Must be unique' },
      { name: 'email', label: 'E-mail', type: 'email', required: true }, { name: 'phone', label: 'Phone' },
      { name: 'departmentId', label: 'Department / specialisation', type: 'lookup', lookup: 'departments', required: true },
      { name: 'batch', label: 'Batch', required: true, placeholder: '2025-27' },
      { name: 'cgpa', label: 'CGPA (0–10)', type: 'number', step: '0.01' }, { name: 'activeBacklogs', label: 'Active backlogs', type: 'number' },
      { name: 'historyBacklogs', label: 'Backlog history', type: 'number' },
      { name: 'status', label: 'Placement status', type: 'select', options: ['Unplaced', 'In Process', 'Placed', 'Opted Out'] },
      { name: 'internshipStatus', label: 'Internship status', type: 'select', options: ['None', 'Ongoing', 'Completed', 'PPO Converted'] },
      { name: 'preferredDomain', label: 'Preferred domain' },
      { name: 'coordinatorId', label: 'Student coordinator', type: 'lookup', lookup: 'coordinators', hideFor: () => !can('students:write') },
      { name: 'skills', label: 'Skills', type: 'tags', span: 2, placeholder: 'Excel, SQL, Power BI' },
    ],
    columns: [
      { key: 'name', label: 'Student', render: (r) => <div><p className="font-semibold">{r.name}</p><p className="text-[13px] text-mute">{r.rollNo}{r.email ? ` · ${r.email}` : ''}</p></div> },
      { key: 'departmentName', label: 'Department', render: (r) => <Badge tone="violet">{r.departmentCode}</Badge> },
      { key: 'batch', label: 'Batch' },
      { key: 'cgpa', label: 'CGPA', render: (r) => <span className="font-num font-bold">{Number(r.cgpa).toFixed(2)}</span>, sort: (r) => r.cgpa },
      { key: 'activeBacklogs', label: 'Backlogs' },
      ...(user!.role === 'corporate_recruiter' ? [{ key: 'skills', label: 'Skills', render: (r: any) => (r.skills || []).join(', ') || '—' }] : [
        { key: 'status', label: 'Status', render: (r: any) => <StatusBadge value={r.status} /> },
        { key: 'coordinatorName', label: 'Coordinator', render: (r: any) => r.coordinatorName || <span className="text-mute">—</span> }]),
    ],
    canCreate: () => can('students:write'),
    topSlot: (items) => (
      <StatsRow stats={[
        { label: 'Students', value: items.length, hint: 'in your view', icon: GraduationCap, tone: 'indigo' },
        { label: 'Placed', value: count(items, (s) => s.status === 'Placed'), hint: 'accepted offers', icon: CheckCircle2, tone: 'aqua' },
        { label: 'In process', value: count(items, (s) => s.status === 'In Process'), icon: Clock, tone: 'violet' },
        { label: 'Unplaced', value: count(items, (s) => s.status === 'Unplaced'), hint: 'need attention', icon: Target, tone: 'coral' }]} />),
  };
  return <ResourcePage cfg={cfg} />;
}
