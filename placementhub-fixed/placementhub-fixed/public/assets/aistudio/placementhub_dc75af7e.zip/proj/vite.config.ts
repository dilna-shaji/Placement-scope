import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const target = env.VITE_API_PROXY || 'http://127.0.0.1:5000';
  return {
    plugins: [react(), tailwindcss()],
    // The API is proxied so the session cookie is same-origin (no CORS, SameSite=Lax works).
    server: { port: 3000, host: '0.0.0.0', proxy: { '/api': { target, changeOrigin: false } } },
    preview: { port: 3000, proxy: { '/api': { target, changeOrigin: false } } },
  };
});
