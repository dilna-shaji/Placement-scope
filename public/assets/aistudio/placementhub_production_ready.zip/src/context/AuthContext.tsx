import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api, setUnauthenticatedHandler } from '../lib/api';
import type { AuthUser, Lookups } from '../types';

interface AuthCtx {
  user: AuthUser | null;
  loading: boolean;
  lookups: Lookups;
  can: (perm: string) => boolean;
  login: (body: Record<string, unknown>) => Promise<AuthUser>;
  logout: () => Promise<void>;
  setUser: (u: AuthUser) => void;
  refreshLookups: () => Promise<void>;
  sessionExpired: boolean;
}

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [lookups, setLookups] = useState<Lookups>({});
  const [sessionExpired, setExpired] = useState(false);

  const refreshLookups = useCallback(async () => {
    try { setLookups(await api.get<Lookups>('/api/lookups')); } catch { /* password change pending etc. */ }
  }, []);

  useEffect(() => {
    api.get<{ user: AuthUser }>('/api/auth/me')
      .then((r) => { setUserState(r.user); if (!r.user.mustChangePassword) refreshLookups(); })
      .catch(() => setUserState(null))
      .finally(() => setLoading(false));
    setUnauthenticatedHandler(() => { setUserState((u) => { if (u) setExpired(true); return null; }); });
  }, [refreshLookups]);

  const value = useMemo<AuthCtx>(() => ({
    user, loading, lookups, sessionExpired,
    can: (p) => !!user?.permissions.includes(p),
    login: async (body) => {
      const r = await api.post<{ user: AuthUser }>('/api/auth/login', body);
      setExpired(false);
      setUserState(r.user);
      if (!r.user.mustChangePassword) refreshLookups();
      return r.user;
    },
    logout: async () => { try { await api.post('/api/auth/logout'); } catch { /* ignore */ } setUserState(null); setLookups({}); window.location.hash = ''; },
    setUser: (u) => { setUserState(u); if (!u.mustChangePassword) refreshLookups(); },
    refreshLookups,
  }), [user, loading, lookups, sessionExpired, refreshLookups]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useAuth = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth outside AuthProvider');
  return c;
};
